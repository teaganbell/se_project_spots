## Spots

### Description

- Tech Stack
- Figma
- Deployment

**Tech Stack**

This project is made so all the elements are displayed correctly on popular screen sizes. It also includes
. HTML
. CSS
. Responsive Design

**Figma**

- [Link to the project on Figma](https://www.figma.com/file/BBNm2bC3lj8QQMHlnqRsga/Sprint-3-Project-%E2%80%94-Spots?type=design&node-id=2%3A60&mode=design&t=afgNFybdorZO6cQo-1)

**Deployment**

This Webpage is deployed to Git-Hub Pages

. [Deployment Link](https://jvirgil760.github.io/se_project_spots/)

The link to my video: https://www.loom.com/share/9eadd1a71820475e93787053621b1a1f?sid=8117b5e1-cbf0-42fd-954e-8f5bb28179c8
