export function setButtonText(btn, isLoading, defaultText, loadingText) {
  if (isLoading) {
    // set the loading text
  } else {
    // set not loading text
  }
}
